﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace Stage0
{
	partial class Program
	{
		static partial void Welcome2367()
		{
			Console.WriteLine("I am also here!");
		}
	}
}
