﻿
namespace DO;
public struct Enums
{
    public enum Category { Dresses, Skirts, Shirts, Accessories, shoes }

}

