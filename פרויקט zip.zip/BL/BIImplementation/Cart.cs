﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BIApi;
namespace BIImplementation
{
    internal class  Cart :ICart
    {
        //מימושים של הפונקציות
    }
}
