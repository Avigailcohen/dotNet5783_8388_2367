﻿using BIApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BIImplementation
{
    internal class  Product: IProduct
    {

    }
}
