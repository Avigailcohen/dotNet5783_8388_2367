﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BIApi
{
    public interface ICart
    {

        //public int AddProduct(BO.Product);
        //פה נכניס את שאר ההצהרות על המתודות 

    }
}
